import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: '
  <product-list></product-list>
  ',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Property-Binding';
}
