import { Component } from '@angular/core';

@Component({
  selector: 'product-root',
  templateUrl: './product-root.component.html',
})
export class ProductListComponent {
  pageTitle: string = 'Product List Page';
}
